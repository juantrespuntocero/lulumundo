import sys
import urllib.parse
import xbmcgui
import xbmcplugin

# Datos de los canales (Nombre y ID de AceStream)
CANALES = [
    {"nombre": "DAZN 1", "id": "897e73c9d578848f596585314ecb9ae067c0e229"},
    {"nombre": "MOVISTAR LA LIGA", "id": "c30b600cc48899991b452805df48b68d998e61c"},
    {"nombre": "MOVISTAR LIGA DE CAMPEONES", "id": "0f7842f8b6c26571e5a974407b61623e56e6a052"},
]

def build_menu():
    handle = int(sys.argv[1])
    # Iteramos sobre la lista de canales para crear los elementos del menú
    for canal in CANALES:
        # Creamos el objeto visual del canal
        list_item = xbmcgui.ListItem(label=canal["nombre"])
        list_item.setInfo("video", {"title": canal["nombre"]})
        
        # URL que se ejecutará al pulsar el canal (llama a Horus)
        url_horus = f"plugin://script.module.horus/?action=play&id={canal['id']}"
        
        # Añadimos el canal al listado de Kodi
        # isFolder=False porque es un archivo reproducible, no una carpeta
        xbmcplugin.addDirectoryItem(handle=handle, url=url_horus, listitem=list_item, isFolder=False)

    # Finalizamos el directorio para que Kodi lo muestre
    xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    build_menu()