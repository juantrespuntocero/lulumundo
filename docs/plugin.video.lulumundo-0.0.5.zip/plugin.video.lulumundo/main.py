import sys # Importante añadir esta línea arriba
import xbmcgui
import xbmcplugin
import requests
import re

URL_M3U = "https://raw.githubusercontent.com/juantrespuntocero/lulumundo/refs/heads/main/docs/lista.m3u"

def listar_canales(handle):
    try:
        contenido = requests.get(URL_M3U).text
        matches = re.findall(r'#EXTINF:.*?,(.*?)\n(plugin://script.module.horus/.*?)\s', contenido + '\n')
        
        for nombre, url in matches:
            list_item = xbmcgui.ListItem(label=nombre)
            list_item.setInfo('video', {'title': nombre})
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=False)
            
    except Exception as e:
        xbmcgui.Dialog().notification("Error", "No se pudo cargar la lista")

    xbmcplugin.endOfDirectory(handle)

# --- ESTO ES LO QUE HACE QUE EL CODIGO ARRANQUE ---
if __name__ == '__main__':
    # sys.argv[1] es el identificador numérico que Kodi asigna al addon al abrirse
    handle = int(sys.argv[1])
    listar_canales(handle)
